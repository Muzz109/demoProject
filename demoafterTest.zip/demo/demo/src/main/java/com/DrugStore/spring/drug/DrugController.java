package com.DrugStore.spring.drug;


import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "api/v1/drug")
public class DrugController {

     private final DrugService drugService;

    public DrugController(DrugService drugService) {
        this.drugService = drugService;
    }


    @GetMapping
    public List<Drug> getDrugs(){
        return drugService.getDrugs();
    }

    @PostMapping
    public void registerNewDrug(@RequestBody Drug  drug){
        drugService.addNewDrug(drug);

    }

    @DeleteMapping(path ="{drugId}")
    public void deletedrug(@PathVariable ("drugId") Long drugId){
        drugService.deleteDrug(drugId);

    }

    @PutMapping(path = "{drugId}")
    public void updateDrug(
            @PathVariable("drugId") Long drugId,
            @RequestParam(required = false) String drugName,
            @RequestParam(required = false) Integer quantity){
        drugService.updateDrug(drugId,drugName,quantity);
    }


}
