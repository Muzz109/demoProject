package com.DrugStore.spring.drug;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.time.Month;
import java.util.List;

@Configuration
public class DrugConfig {

    @Bean
    CommandLineRunner commandLineRunner(DrugRepository repository){
        return args->{
           Drug d1= new Drug(
                    "Crocin",
                    LocalDate.of(2020, Month.AUGUST,2 ),
                    "Paracetomol",
                    "pfixer123@gmail.com",
                    5000

            );
            Drug d2= new Drug(
                    "Sumo",
                    LocalDate.of(2010, Month.AUGUST,2 ),
                    "Paracetomol",
                    "pastra123@gmail.com",
                    400

            );

            repository.saveAll(
                    List.of(d1, d2)
            );
        };


    }


}



