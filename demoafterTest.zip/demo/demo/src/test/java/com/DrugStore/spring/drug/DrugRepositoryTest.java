package com.DrugStore.spring.drug;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.time.LocalDate;
import java.time.Month;
import java.util.Optional;

import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;

@DataJpaTest
class DrugRepositoryTest {

    @Autowired
    private DrugRepository underTest;

    @BeforeEach
    void setUp() {

    }

    @AfterEach
    void tearDown(){
        underTest.deleteAll();
    }



    @Test    // First Unit test
    void findDrugByNameExist() {

        //given
        String drugName = "Crocin";
        Drug drug = new Drug(

                drugName,
                LocalDate.of(2020, Month.AUGUST,2 ),
                "Paracetomol",
                "pfixer123@gmail.com",
                5000
        );
        underTest.save(drug);
        //when
        System.out.println("The value of drugName is "+drugName);
         Optional<Drug> exist = underTest.findDrugByName(drugName);
         System.out.println("The value of "+exist);


        //then
        assertThat(exist).isNotEmpty();

    }

    @Test    // First Unit test
    void findDrugByNameDosenotExist() {

        //given
        String drugName = "Crocin";

        //when
        System.out.println("The value of drugName is "+drugName);
        Optional<Drug> exist = underTest.findDrugByName(drugName);
        System.out.println("The value of "+exist);


        //then
        assertThat(exist).isEmpty();

    }



}