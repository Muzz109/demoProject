package com.DrugStore.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;


class DrugManagementSystemApplicationTests {

	Calculator underTest = new Calculator();


	@Test
	void itshoulAddtwoNumbers() {

		// given
		int m1 = 10;
		int m2 = 30;
		//when
		int result = underTest.add(m1, m2);

		//then

		assertThat(result).isEqualTo(40);
	}

	class Calculator {
		int add(int a, int b) {
			return a + b;
		}

	}

}


