package com.DrugStore.spring.drug;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.time.LocalDate;
import java.time.Month;
import java.util.Objects;
import java.util.Optional;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.assertj.core.api.AssertionsForClassTypes.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)  //Intiytializes the afterEach and the associated config
class DrugServiceTest {
    @Mock
    private DrugRepository drugRepository;
    private DrugService underTest;
 ;

    @BeforeEach
    void setUp() {


        underTest= new DrugService(drugRepository);
    }




    @Test
    void getAllDrugs() {    // unit test to check the
      underTest.getDrugs();
      verify(drugRepository).findAll();


    }

    @Test

    void canaddNewDrug() {

        //given
        Drug drug = new Drug(

                "Crocin",
                LocalDate.of(2020, Month.AUGUST,2 ),
                "Paracetomol",
                "pfixer123@gmail.com",
                5000
        );

        //when
        underTest.addNewDrug(drug);

        //then
        ArgumentCaptor<Drug> drugArgumentCaptor =
                ArgumentCaptor.forClass(Drug.class);

        verify(drugRepository).save(drugArgumentCaptor.capture());

        Drug capDrug1 =   drugArgumentCaptor.getValue();
        assertThat(capDrug1).isEqualTo(drug);

    }

    @Test
    void willthrowwhenDrugNameistaken() {

        //given
        Drug drug = new Drug(

                "Crocin",
                LocalDate.of(2020, Month.AUGUST,2 ),
                "Paracetomol",
                "pfixer123@gmail.com",
                5000
        );  //drug.getDrugName())
         given(drugRepository.findDrugByName(anyString())).willReturn(Optional.of(drug));
        //when
        //then
       assertThatThrownBy( ()->underTest.addNewDrug(drug))
               .isInstanceOf(IllegalStateException.class)
               .hasMessageContaining("Already Exist");

       verify(drugRepository,never()).save(any()); //repository never save

    }



    @Test

    void deleteDrug() {
        long drugId =1;
        assertThat(drugRepository.existsById(drugId));


        assertThatThrownBy( ()->underTest.deleteDrug(drugId))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("the drug with id dosnent exist");

        verify(drugRepository,never()).delete(any());


    }


    @Test

    void updateDrug() {
        long drugId =1;
        String DrugName ="Crocin";
        Integer quantity =200;
        Drug drug = new Drug();

        assertThat(drugRepository.existsById(drugId));



        //when
        //then
        assertThatThrownBy( ()->underTest.updateDrug(drugId,DrugName,quantity))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("The drug with id dosent exist");
        drug.setDrugId(drugId);
         drug.setDrugName(DrugName);
         drug.setQuantity(quantity);

        verify(drugRepository,never()).saveAndFlush(drug);

    }
}