package com.DrugStore.spring.drug;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class DrugService {


    private final DrugRepository drugRepository;

    @Autowired
    public DrugService(DrugRepository drugRepository) {
        this.drugRepository = drugRepository;
    }

    public List<Drug> getDrugs(){

   return drugRepository.findAll();



    }

    public void addNewDrug(Drug drug) {
        Optional<Drug> drugOptional =drugRepository
                .findDrugByName(drug.getDrugName());

        if(drugOptional.isPresent()){
            throw new IllegalStateException("Already Exist");

        }
        drugRepository.save(drug);

       /* System.out.println(drug);*/
}

   public void deleteDrug(long drugId){
      boolean exist =drugRepository.existsById(drugId);
        if(!exist){
            throw new IllegalStateException("the drug with id dosnent exist" );
        }
        drugRepository.deleteById(drugId);


   }

   @Transactional
   public void updateDrug(Long drugId,String drugName, Integer quantity ){
        Drug drug = drugRepository.findById(drugId).orElseThrow(()-> new IllegalStateException(
                "The drug with id dosent exist"
        ));

       if (drugName != null && drugName.length() > 0 && Objects.equals(drug.getDrugName(), drugName)) {
           drug.setDrugName(drugName);
       }

       if (quantity!= null ){
           drug.setQuantity(quantity);
       }
   }



}
