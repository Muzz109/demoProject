package utils;

public class DrugManagementSystemApplication {


}
