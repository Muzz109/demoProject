package com.DrugStore.spring;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//change
@SpringBootTest
class DrugManagementSystemApplicationTests {

	private DrugManagementSystemApplicationTests drugManagementSystemApplicationTests;

	@BeforeEach
	void setUp(){
		drugManagementSystemApplicationTests = new DrugManagementSystemApplicationTests();
	}

	@Test
	void contextLoads() {
	}

	@Test
	public  void testvalidation(){

	}

}
